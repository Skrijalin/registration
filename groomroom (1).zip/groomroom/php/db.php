<?php
session_start();
$link = new  mysqli("localhost","mrt22","123456789sS1","mrt2");

if($link->connect_errno){
echo "Ошибка в подклучение в db: $link->connect_error";
}
?>